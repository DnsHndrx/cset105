let arr_1=[2,4,6,8]
let firstsum=0;
for (let x= 0; x<arr_1.length; x++){
    firstsum+=arr_1[x]
}
return firstsum