let numb= prompt("Enter variable : ");
let range= prompt("Enter a range: ");
let multiple= prompt("Enter a multiple: ");

for(let x = multiple; x <= range; x++) {
    let result = i * numb;
    console.log(`${numb} * ${x} = ${result}`);
}