function add(x,y,z){
    if(z== undefined){
    return (x+y)
    }
    else{
         return (x+y+z)
    }
} 
console.log(2+3)
console.log(2+3+4)