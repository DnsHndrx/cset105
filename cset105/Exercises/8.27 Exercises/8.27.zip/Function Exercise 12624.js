function nthexercise (x){
    let p= 1;
    for (let u=2; u<=x; u++){
        p=u*x;
    }
}
return p;