function nthexercise (x){
    let p= 2;
    for (let u=2; u<=x; u++){
        p=p*2+4;
    }
}
return p;