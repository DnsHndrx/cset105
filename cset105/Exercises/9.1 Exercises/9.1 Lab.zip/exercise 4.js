let letters= "Hello World";
let invert= letters.split("").map(function(i)){
    return i==
    i.toUpperCase()?
    i.toLowerCase():
    i.toUpperCase()

}).join("")
console.log(invert)