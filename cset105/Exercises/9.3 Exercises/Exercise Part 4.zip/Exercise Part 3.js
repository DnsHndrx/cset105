var people=["Greg", "Mary", "Devon", "James"];
people.shift()
people.pop()
people.unshift("Matt")
people.push("Denise")

console.log(people.slice (2,4))