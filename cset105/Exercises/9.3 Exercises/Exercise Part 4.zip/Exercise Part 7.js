var people=["Greg", "Mary", "Devon", "James"];
var withBob= people.concat("Bob")
console.log(withBob)