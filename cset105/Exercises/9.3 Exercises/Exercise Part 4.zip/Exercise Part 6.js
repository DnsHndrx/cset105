var people=["Greg", "Mary", "Devon", "James"];
people.splice(2,0 "Elizabeth", "Artie")

console.log(people)