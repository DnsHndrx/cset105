var people=["Greg", "Mary", "Devon", "James"];
people.shift()
people.pop()
people.unshift("Matt")
people.push("Denise")

let items= people.indexOf("Foo", 0)

console.log(items)