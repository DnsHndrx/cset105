var people=["Greg", "Mary", "Devon", "James"];
people.shift()
people.pop()
people.unshift("Matt")
people.push("Denise")

for(let i=0; i< people.length; i++){
    console.log(people[i])
}
