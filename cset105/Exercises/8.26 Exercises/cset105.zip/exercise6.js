for(let d=1; d<=10; d++){
    console.log(`3*${d}=${d*3}`)
} 
for(let u=1; u<=10; u++){
    console.log(`17*${u}=${u*17}`)
} 