let symbol = "#"
do
{
    console.log(symbol);
    symbol=symbol+"#";
} while(symbol <= "#######")